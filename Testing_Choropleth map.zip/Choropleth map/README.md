Source: [California Civic Data Coalition](https://github.com/california-civic-data-coalition/python-calaccess-notebooks/blob/master/project-management/mooc-students.ipynb)

This map shows the number of students in each country enrolled in the online class ["Python for Data Journalists"](http://journalismcourses.org/PDJ0517.html) taught by [Ben Welsh](http://palewi.re/who-is-ben-welsh/) and the [California Civic Data Coalition](http://www.californiacivicdata.org/) in 2017. More than 2,700 total students from more than 120 countries participated in the month-long course.

The code uses d3 version 4 and a [threshold scale](https://github.com/d3/d3-scale/blob/master/README.md#scaleThreshold). It is based on previous choropleth maps [published by Mike Bostock](https://bl.ocks.org/mbostock/4060606).
